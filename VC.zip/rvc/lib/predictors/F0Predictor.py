class F0Predictor(object):
    def compute_f0(self, wav, p_len):
        pass

    def compute_f0_uv(self, wav, p_len):
        pass
